package authenticationRepository

import (
	"bytes"
	"encoding/json"
	"errors"
	"io/ioutil"
	"log"
	"net/http"
	"fmt"

	"iqoption-sdk/src/configs"
)

type ResponseLogin struct {
	Code    string
	Ssid    string
	Message string
}

func GetSSID() (responseSsid chan string, responseError chan error) {
	responseSsid = make(chan string)
	responseError = make(chan error)

	go func() {

		requestBody, _ := json.Marshal(map[string]string{
			"identifier": "diegocarvalho.dev@gmail.com", //configs.GetIqOptionEmail(),
			"password":   "12345678", //configs.GetIqOptionPassword(),
		})

		response, err := http.Post("https://"+configs.IqoptionAuthHOst+"/api/v2/login", "application/json", bytes.NewBuffer(requestBody))
			//https://api.trade.bull-ex.com/v2/login

		if err != nil {
			log.Printf("An Error Occured %v", err)
			responseSsid <- ""
			responseError <- err

			fmt.Println("err ws 01")

			return
		}

		defer response.Body.Close()

		responseJson, err := ioutil.ReadAll(response.Body)
		
		if len(responseJson) == 0 {
			log.Println("O corpo da resposta está vazio.")
			// Mesmo vazio, podemos ter recebido um status code importante (ex: 204 No Content)
			return
		}

		// 5. Agora, com todas as verificações, imprimimos a string
		// Esta é a sua conversão, que agora deve funcionar.
		responseString := string(responseJson)

		fmt.Println("--- INÍCIO DA RESPOSTA DA API ---")
		fmt.Println("login :" + configs.GetIqOptionEmail())
		fmt.Println("pass :" + configs.GetIqOptionPassword())
		fmt.Println(responseString)
		fmt.Println("--- FIM DA RESPOSTA DA API ---")

		if err != nil {
			log.Printf("An Error Occured %v", err)
			responseSsid <- ""
			responseError <- err

			fmt.Println("err ws 02")
			return
		}

		var responseLogin ResponseLogin
		err = json.Unmarshal(responseJson, &responseLogin)

		if err != nil {
			responseSsid <- ""
			responseError <- err

			fmt.Println("err ws 03")
			fmt.Println(err)
		}
		if responseLogin.Code != "success" {
			responseSsid <- ""
			responseError <- errors.New(responseLogin.Message)

			fmt.Println("err ws 04")
			return
		}
		responseSsid <- string(responseLogin.Ssid)
		responseError <- nil

		fmt.Println("err ws 05")
	}()
	return
}
