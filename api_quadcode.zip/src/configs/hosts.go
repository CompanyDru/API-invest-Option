package configs

const (
	IqoptionAuthHOst      string = "auth.trade.bull-ex.com"
	IqoptionWebSocketHost string = "ws.trade.bull-ex.com"
)

/*
ws.trade.bull-ex.com/echo/websocket
*/