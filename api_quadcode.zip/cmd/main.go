package cmd

import (
	"os"
	"os/signal"
	"fmt"

	"iqoption-sdk/src/configs"
	"iqoption-sdk/src/repositories/iqoptionRepository"
)

func Start() {
	interrupt := make(chan os.Signal, 1)
	signal.Notify(interrupt, os.Interrupt)

	iqOptionRepository := iqoptionRepository.IqOptionRepository{}
	connection, err := iqOptionRepository.Connect(configs.GetAccountType())
	if err != nil {
		fmt.Println(err)
		panic(err)
	}

	connection.GetAllActiveBinaryInfo()

	activeId := 1972
	duration := 1
	investiment := 5.00
	direction := "call"

	go connection.OpenOrder(activeId, duration, investiment, direction)

	<-interrupt
}
